//
//  GroceryItem+CoreDataClass.swift
//  NoteTakingApp
//
//  Created by MacStudent on 2018-07-11.
//  Copyright © 2018 robin. All rights reserved.
//
//

import Foundation
import CoreData

@objc(GroceryItem)
public class GroceryItem: NSManagedObject {

}
