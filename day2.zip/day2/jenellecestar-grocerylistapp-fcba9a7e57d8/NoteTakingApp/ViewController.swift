//
//  ViewController.swift
//  NoteTakingApp
//
//  Created by robin on 2018-07-09.
//  Copyright © 2018 robin. All rights reserved.
//

import UIKit
import CoreData
class ViewController: UIViewController {

    
    @IBOutlet weak var noteText: UITextField!
    
    var groceryList: [GroceryListItem] = []
    
    @IBOutlet weak var textView: UITextView!
    var managedContext: NSManagedObjectContext?  // making the variable global
    override func viewDidLoad() {
        super.viewDidLoad()
        
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else{return}
         managedContext = appDelegate.persistentContainer.viewContext
        
        // Do any additional setup after loading the view, typically from a nib.
        //addSampleData()
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

   /*
    func addSampleData() {
        for x in 1...5 {
            
            let randomWords = "This is item \(x)"
            
            let item:GroceryListItem = GroceryListItem(item: randomWords)

            groceryList.append(item)
        }
    }
*/
    @IBAction func addNote(_ sender: Any) {
        print("clicked!")
        
        // check if textbox is empty
        guard let x = noteText.text , x != "" else {
            print("textbox is empty")
            return
        }
        //=======================================
        //1. create a new CoreData GroceryItem object
        
        let groceryItemEntity = NSEntityDescription.entity(forEntityName: "GroceryItem", in: managedContext!)
        let item = NSManagedObject(entity: groceryItemEntity!, insertInto: managedContext!)
        
        //2. set the properties of the coredata
        item.setValue(noteText.text!, forKey: "itemName")//from textbox
        item.setValue(Date(), forKey: "dateAdded")// Date()-> automatically creates todays date
        //3. save object to database
        do{
        try managedContext!.save()
        }
        catch{
            print("error saving to database")
        }
        //=======================================
        // create a note and save to system
       /* let item : GroceryListItem = GroceryListItem(item:x)
        groceryList.append(item);
        */
        // clear the textbox
        noteText.text = ""
        
        // create an alert box to show user
        
        // -- make an alert
        let alert = UIAlertController(title: "Save Complete", message: "Your item was saved!", preferredStyle: .alert)
        
        // -- add a button
        alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default,handler: nil))
        
        // -- show the popup
        self.present(alert, animated: true, completion: nil)
       
        
    }

    @IBAction func showAll(_ sender: Any) {
        
        
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName:"GroceryItem")
        
        
        //3. send query t6o database
        do{
        
        let rows = try managedContext!.fetch(fetchRequest)
            
            for item in rows{
                let x = item as! GroceryItem
                print("\(x.dateAdded!): \(x.itemName!)")
            }
            
            
        }
        catch{
            print("Error fetching data from database")
        }
        
        for item in groceryList {
            print("\(item.dateAdded): \(item.itemName)")
        }
    }
}

